"""Shared helpers for spawning/stopping the per-session heartbeat daemon and
the singleton log forwarder daemon. Used by both AnchorCallbackHandler
(automatic, session-per-root-run tracking) and AnchorSession (explicit,
manual control for non-callback use cases) so the subprocess-management
logic exists in exactly one place.
"""
from __future__ import annotations

import os
import signal
import subprocess
import sys


def _daemon_cmd(config, module: str, *extra_args: str):
    cmd = [sys.executable, "-m", module, *extra_args]
    if config.source_path:
        cmd += ["--config", config.source_path]
    return cmd


def start_heartbeat_daemon(config, session_id: str) -> None:
    pid_path = config.heartbeat_pid_path(session_id)
    pid_path.parent.mkdir(parents=True, exist_ok=True)
    if pid_path.exists():
        return  # already running for this session
    proc = subprocess.Popen(
        _daemon_cmd(
            config,
            "anchor_hooks.heartbeat_daemon",
            "--session-id", session_id,
            "--agent-id", config.agent_id,
        ),
        start_new_session=True,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    pid_path.write_text(str(proc.pid))


def stop_heartbeat_daemon(config, session_id: str) -> None:
    pid_path = config.heartbeat_pid_path(session_id)
    if not pid_path.exists():
        return
    try:
        pid = int(pid_path.read_text().strip())
        os.kill(pid, signal.SIGTERM)
    except (ValueError, ProcessLookupError, FileNotFoundError):
        pass
    finally:
        pid_path.unlink(missing_ok=True)


def start_forwarder_daemon(config) -> None:
    pid_path = config.forwarder_pid_path
    pid_path.parent.mkdir(parents=True, exist_ok=True)
    if pid_path.exists():
        try:
            pid = int(pid_path.read_text().strip())
            os.kill(pid, 0)  # raises if not alive
            return  # already running
        except (ValueError, ProcessLookupError, FileNotFoundError):
            pass  # stale pid file -- fall through and restart
    proc = subprocess.Popen(
        _daemon_cmd(config, "anchor_hooks.log_forwarder"),
        start_new_session=True,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    pid_path.write_text(str(proc.pid))
