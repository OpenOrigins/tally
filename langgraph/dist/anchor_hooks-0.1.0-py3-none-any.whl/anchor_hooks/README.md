# anchor-hooks

Tally Anchor-style audit logging for LangGraph agents, distributed as a standalone
`.whl` so it can be dropped into any LangGraph project without pulling in this
repo. See [INTEGRATION.md](INTEGRATION.md) for the full step-by-step procedure
(config reference, what gets logged, restart/troubleshooting) -- this README is
the quick version. Ships three things:

- `AnchorCallbackHandler` -- add one instance to any compiled LangGraph app's
  existing `callbacks` list and it emits SESSION_START/END,
  INSTRUCTION_RECEIVED, ACTION_TAKEN, RESULT_RECEIVED and HANDOFF records for
  every run, with no other change to the agent's code. (`AnchorSession` is
  also available for the rare case where there's no LangChain Runnable to
  attach a callback handler to at all.)
- A per-session heartbeat daemon and a singleton log forwarder daemon, both
  started automatically -- no separate process to manage.
- An `anchor-hooks` CLI for one-time setup: scaffolding config and performing
  the initial handshake with the Tally ingest server.

## Install

```bash
pip install anchor_hooks-0.1.0-py3-none-any.whl
```

## Set up in a project

```bash
cd your-langgraph-project
anchor-hooks init                              # scaffolds anchor_config.yaml + logs/
anchor-hooks connect --api-key <YOUR-API-KEY>   # saves the key to .env and
                                                 # handshakes with the server
```

`connect` writes `TALLY_API_KEY=<key>` into the project's `.env` (creating it
if needed, preserving every other line already in it) and POSTs a one-time
"client connected" notification to the server using that same key, so the
server can confirm this client is wired up before any log records arrive.
The handshake is best-effort: if the server is unreachable, the key is still
saved and log shipping still works -- it just retries delivery on its own
schedule via the forwarder daemon. `log_forwarder.py` reads `TALLY_API_KEY`
from `.env`/the environment fresh on every drain cycle, so it's exactly one
key, shared by both the handshake and every log shipped afterwards -- rotate
it by re-running `connect`, no daemon restart required.

To point at a non-default ingest endpoint, pass `--api-url` (saved as
`TALLY_API_URL` in the same `.env`):

```bash
anchor-hooks connect --api-key <YOUR-API-KEY> --api-url https://your-tally-host/v1/tally/logs
```

If `TALLY_API_KEY` is already set in `.env` (e.g. you added it by hand), you
can run `anchor-hooks connect` with no `--api-key` to just (re-)fire the
handshake.

## Use it in your graph

Add one entry to whatever `callbacks` list you already pass into your
compiled graph's invoke/stream call -- this is the entire integration, no
other change needed regardless of the agent's internal structure:

```python
from anchor_hooks import AnchorCallbackHandler

result = app.invoke(inputs, config={"callbacks": [AnchorCallbackHandler()]})
```

If you already pass other callbacks, just append to that same list:

```python
result = app.invoke(inputs, config={"callbacks": [MyExistingHandler(), AnchorCallbackHandler()]})
```

Construct a fresh `AnchorCallbackHandler()` per invocation (not a shared
singleton reused across many calls) -- it derives SESSION_START/SESSION_END
and INSTRUCTION_RECEIVED from the `on_chain_start`/`on_chain_end` callback
events LangChain already fires for the root run around any single
`.invoke()`/`.stream()` call, so one instance tracks exactly one run.

Every record is appended to `logs/log.jsonl` (and mirrored to
`logs/log.sqlite`) and shipped to the ingest API by a background forwarder
process using the API key saved during `connect` -- no further action
needed.

## Building the wheel

From the repo root (`GitHub_Monitor/`):

```bash
pip install build
python -m build --wheel
```

The wheel lands in `dist/anchor_hooks-0.1.0-py3-none-any.whl` and is
self-contained -- hand it to anyone with Python 3.10+ and the steps above are
all they need.
