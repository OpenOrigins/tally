"""Self-contained LangChain callback handler that turns a LangGraph run into
anchor records. Add ONE instance to any compiled graph's invoke/stream config

    result = app.invoke(inputs, config={"callbacks": [AnchorCallbackHandler()]})

and it captures the whole run -- no other change needed at the call site.
This is deliberately the only integration point: whatever agent it's dropped
into, wiring cost is exactly one import plus one entry in an existing
`callbacks` list.

Session boundaries (SESSION_START/SESSION_END) and INSTRUCTION_RECEIVED are
derived from callback events LangChain already fires for the *root* run
(parent_run_id is None) around any `.invoke()`/`.stream()` call, rather than
requiring an explicit `with session.track(): ...` wrapper -- verified
empirically against langgraph==1.2.11: exactly one on_chain_start/
on_chain_end pair fires with parent_run_id=None per top-level invocation,
wrapping every nested per-node chain call underneath it. That root pair's
`inputs` becomes the INSTRUCTION_RECEIVED payload.

Construct a FRESH instance per invocation (as this file's own doctest-style
usage above does) -- one instance tracks exactly one root run. Reusing an
instance across multiple top-level invoke() calls will only emit
SESSION_START/END for the first one, since `_root_run_id` is only ever set
once.

Mapping:
  - on_chain_start (parent_run_id is None) -> SESSION_START + INSTRUCTION_RECEIVED
  - on_chain_end/on_chain_error (root run_id)  -> SESSION_END
  - on_tool_start/on_tool_end/on_tool_error    -> ACTION_TAKEN / RESULT_RECEIVED
  - on_chain_start (nested subgraph frame)     -> HANDOFF (best-effort, see below)

agent_version is deliberately NOT captured from on_chat_model_start: by the
time any model call fires, SESSION_START has already been written (it's
emitted at the root on_chain_start, before the graph runs), so a
dynamically-discovered model name would always arrive too late. Configure
agent_version explicitly instead (constructor arg / ANCHOR_AGENT_VERSION).

HANDOFF detection relies on LangGraph's `langgraph_checkpoint_ns` metadata,
which grows one `|`-joined segment per level of subgraph nesting -- verified
against langgraph==1.2.11 with a supervisor node routing into two compiled
subgraphs (see anchor_hooks/tests/test_handoff.py). `langgraph_checkpoint_ns`
is an internal implementation detail, not documented public API, so re-verify
this against the client's actual LangGraph version before relying on it in
production.
"""
from __future__ import annotations

import uuid
from typing import Any, Dict, Optional
from uuid import UUID

from langchain_core.callbacks import BaseCallbackHandler

from . import daemons
from .config import AnchorConfig, load_config
from .schema import now_iso, truncate
from .sink import LogSink

TOOL_TRUNCATE_LEN = 2000
INSTRUCTION_TRUNCATE_LEN = 500


class AnchorCallbackHandler(BaseCallbackHandler):
    def __init__(
        self,
        config_path: Optional[str] = None,
        agent_id: Optional[str] = None,
        agent_version: Optional[str] = None,
        principal_id: Optional[str] = None,
        config: Optional[AnchorConfig] = None,
        source: str = "invoke",
    ):
        self.config = config or load_config(config_path)
        if agent_id:
            self.config.agent_id = agent_id
        if agent_version:
            self.config.agent_version = agent_version
        if principal_id:
            self.config.principal_id = principal_id
        self.source = source

        self.sink = LogSink(self.config)
        self._root_run_id: Optional[UUID] = None
        self._session_id: Optional[str] = None
        self._instruction_id: Optional[str] = None
        self._action_ids: Dict[UUID, str] = {}
        self._seen_subgraph_entries = set()
        self._current_toplevel_node: Optional[str] = None
        self._current_toplevel_ns: Optional[str] = None
        self._previous_toplevel_node: Optional[str] = None

    # -- SESSION_START / INSTRUCTION_RECEIVED, driven by the root run -------
    def on_chain_start(self, serialized, inputs, *, run_id, parent_run_id=None, tags=None,
                        metadata=None, **kwargs):
        if parent_run_id is None and self._root_run_id is None:
            self._root_run_id = run_id
            self._session_id = f"sess_{run_id}"

            self.sink.write({
                "schema_version": self.config.schema_version,
                "record_type": "SESSION_START",
                "session_id": self._session_id,
                "agent_id": self.config.agent_id,
                "agent_version": self.config.agent_version,
                "principal": {"type": "user", "id": self.config.principal_id},
                "source": self.source,
                "session_started_at": now_iso(),
            })

            self._instruction_id = f"instr_{str(run_id)[:8]}"
            self.sink.write({
                "schema_version": self.config.schema_version,
                "record_type": "INSTRUCTION_RECEIVED",
                "session_id": self._session_id,
                "instruction_id": self._instruction_id,
                "sender": {"id": self.config.principal_id},
                "declared_intent": {"summary": truncate(str(inputs), INSTRUCTION_TRUNCATE_LEN)},
                "instruction_received_at": now_iso(),
            })

            daemons.start_heartbeat_daemon(self.config, self._session_id)
            daemons.start_forwarder_daemon(self.config)
            return

        self._maybe_emit_handoff(metadata)

    # -- SESSION_END, matched back to the same root run ----------------------
    def _end_session(self, outcome: str) -> None:
        self.sink.write({
            "schema_version": self.config.schema_version,
            "record_type": "SESSION_END",
            "session_id": self._session_id,
            "outcome": outcome,
            "session_ended_at": now_iso(),
        })
        daemons.stop_heartbeat_daemon(self.config, self._session_id)

    def on_chain_end(self, outputs, *, run_id, parent_run_id=None, **kwargs):
        if self._root_run_id is not None and run_id == self._root_run_id:
            self._end_session("completed")

    def on_chain_error(self, error, *, run_id, parent_run_id=None, **kwargs):
        if self._root_run_id is not None and run_id == self._root_run_id:
            self._end_session("error")

    # -- ACTION_TAKEN / RESULT_RECEIVED -----------------------------------
    def on_tool_start(self, serialized, input_str, *, run_id, parent_run_id=None, tags=None,
                       metadata=None, inputs=None, **kwargs):
        action_id = f"act_{run_id}"
        self._action_ids[run_id] = action_id
        tool_name = (serialized or {}).get("name", "unknown_tool")
        params = truncate(str(inputs) if inputs is not None else input_str, TOOL_TRUNCATE_LEN)
        self.sink.write({
            "schema_version": self.config.schema_version,
            "record_type": "ACTION_TAKEN",
            "session_id": self._session_id,
            "action_id": action_id,
            "instruction_id": self._instruction_id,
            "action_type": "tool_call",
            "tool": {"name": tool_name, "params": params},
            "pre_state_hash": "0" * 64,
            "post_state_hash": None,
            "action_timestamp": now_iso(),
            "deviance_flag": {"deviated": False, "delta_category": None},
        })

    def on_tool_end(self, output, *, run_id, parent_run_id=None, **kwargs):
        self._emit_result(run_id, truncate(str(output), TOOL_TRUNCATE_LEN), exception=False)

    def on_tool_error(self, error, *, run_id, parent_run_id=None, **kwargs):
        self._emit_result(run_id, truncate(str(error), TOOL_TRUNCATE_LEN), exception=True)

    def _emit_result(self, run_id: UUID, summary: Optional[str], exception: bool) -> None:
        action_id = self._action_ids.pop(run_id, f"act_{run_id}")
        self.sink.write({
            "schema_version": self.config.schema_version,
            "record_type": "RESULT_RECEIVED",
            "session_id": self._session_id,
            "action_id": action_id,
            "result_interpretation": {"summary": summary},
            "result_received_at": now_iso(),
            "exception": {"occurred": exception},
        })

    # -- HANDOFF (best-effort) ---------------------------------------------
    def _maybe_emit_handoff(self, metadata: Optional[Dict[str, Any]]):
        if not metadata:
            return
        ns = metadata.get("langgraph_checkpoint_ns", "")
        segments = [s for s in ns.split("|") if s]
        if not segments:
            return

        if len(segments) == 1:
            # A depth-1 frame is some top-level node of the (sub)graph we're
            # currently in. LangGraph fires this for a plain node AND for a
            # node that turns out to be a nested compiled subgraph -- at this
            # point we can't yet tell which, so just track "most recent
            # distinct top-level node" and wait for a depth-2 frame to prove
            # it was a subgraph.
            if segments[0] != self._current_toplevel_ns:
                self._previous_toplevel_node = self._current_toplevel_node
                self._current_toplevel_node = segments[0].split(":")[0]
                self._current_toplevel_ns = segments[0]
            return

        # depth >= 2: we're inside a nested subgraph -- confirms the current
        # top-level node is actually a subagent. Fire HANDOFF once per entry.
        subgraph_key = segments[0]
        if subgraph_key in self._seen_subgraph_entries:
            return
        self._seen_subgraph_entries.add(subgraph_key)
        receiving_subagent = subgraph_key.split(":")[0]
        sending_agent = self._previous_toplevel_node or "unknown"
        self.sink.write({
            "schema_version": self.config.schema_version,
            "record_type": "HANDOFF",
            "session_id": self._session_id,
            "handoff_id": f"handoff_{uuid.uuid4().hex[:8]}",
            "sending_agent": sending_agent,
            "receiving_subagent_type": receiving_subagent,
            "acknowledgement_status": "pending",
            "handoff_at": now_iso(),
        })
