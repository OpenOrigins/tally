"""Installer: `anchor-hooks init` scaffolds the directories and config file a
client needs to drop anchor hooks into their own LangGraph agent, and
`anchor-hooks connect` wires up the API key and performs the initial
handshake with the Tally ingest API. Both are exposed as the `anchor-hooks`
console script once this package is installed from its .whl.
"""
from __future__ import annotations

import argparse
import os
from pathlib import Path
from typing import Optional

from .handshake import notify_client_connected

CONFIG_TEMPLATE = """\
# Anchor hooks configuration. Values here can be overridden by environment
# variables (ANCHOR_AGENT_ID, ANCHOR_AGENT_VERSION, TALLY_USER_EMAIL,
# TALLY_API_URL). The API key itself lives in .env as TALLY_API_KEY -- see
# `anchor-hooks connect`.
agent_id: local-agent:CHANGE-ME
agent_version: unknown  # set to your model/build version, or pass AnchorCallbackHandler(agent_version=...)
principal_id: user:CHANGE-ME@example.com
log_dir: logs
heartbeat_interval_seconds: 60
heartbeat_max_hours: 6
forwarder:
  api_url: https://api.dev2.openorigins.com/v1/tally/logs
  max_hours: 24
"""

INTEGRATION_SNIPPET = """
Integration snippet -- add ONE entry to whatever `callbacks` list you
already pass into your compiled graph's invoke/stream config (or add a
`callbacks=[...]` config if you don't have one yet). Nothing else changes --
no wrapping, no explicit start/end calls:

    from anchor_hooks import AnchorCallbackHandler

    result = app.invoke(inputs, config={"callbacks": [AnchorCallbackHandler()]})

Construct a fresh AnchorCallbackHandler() per invocation (not a shared
singleton reused across calls) -- it tracks exactly one run's session
lifecycle, the same way this codebase already constructs its own callback
handlers fresh per call.
"""


def _upsert_env_var(env_path: Path, key: str, value: str) -> None:
    """Set `key=value` in a .env file, replacing an existing line for that key
    in place (preserving every other line) or appending a new one. Creates
    the file if it doesn't exist yet.
    """
    lines = env_path.read_text().splitlines() if env_path.exists() else []
    prefix = f"{key}="
    for i, line in enumerate(lines):
        if line.startswith(prefix):
            lines[i] = f"{key}={value}"
            break
    else:
        lines.append(f"{key}={value}")
    env_path.write_text("\n".join(lines) + "\n")


def init(target_dir: str = ".") -> None:
    root = Path(target_dir)
    (root / "logs").mkdir(parents=True, exist_ok=True)

    config_path = root / "anchor_config.yaml"
    if not config_path.exists():
        config_path.write_text(CONFIG_TEMPLATE)
        print(f"Wrote {config_path}")
    else:
        print(f"{config_path} already exists, leaving it untouched")

    env_path = root / ".env"
    if not (env_path.exists() and "TALLY_API_KEY=" in env_path.read_text()):
        print(f"No API key yet -- run: anchor-hooks connect --api-key <YOUR-KEY> --dir {target_dir}")

    print(INTEGRATION_SNIPPET)


def connect(api_key: Optional[str] = None, api_url: Optional[str] = None, target_dir: str = ".") -> None:
    """Save TALLY_API_KEY (and optionally TALLY_API_URL) into the project's
    .env and perform the initial handshake with the Tally ingest API using
    that same key -- the one log_forwarder.py reads on every drain cycle
    afterwards, so there is exactly one place the key lives. Safe to re-run
    to rotate the key or point at a new endpoint.
    """
    root = Path(target_dir)
    env_path = root / ".env"

    resolved_api_key = (api_key or "").strip() or os.environ.get("TALLY_API_KEY", "").strip()
    if not resolved_api_key:
        raise SystemExit(
            f"API key is required -- pass --api-key, or set TALLY_API_KEY in {env_path} first."
        )
    if api_key:
        _upsert_env_var(env_path, "TALLY_API_KEY", resolved_api_key)
        print(f"Set TALLY_API_KEY in {env_path}")

    resolved_api_url = (api_url or "").strip() or os.environ.get("TALLY_API_URL", "").strip()
    if api_url:
        _upsert_env_var(env_path, "TALLY_API_URL", resolved_api_url)
        print(f"Set TALLY_API_URL in {env_path}")
    if not resolved_api_url:
        from .config import ForwarderConfig

        resolved_api_url = ForwarderConfig.api_url

    if notify_client_connected(resolved_api_key, resolved_api_url):
        print("Handshake succeeded -- server has marked this client as connected.")
    else:
        print(
            "Handshake could not reach the server right now -- this is non-fatal, "
            "the API key is saved and the log forwarder will still ship records "
            "(retrying the handshake is not required for that to work)."
        )


def main():
    parser = argparse.ArgumentParser(prog="anchor-hooks")
    sub = parser.add_subparsers(dest="command", required=True)

    init_parser = sub.add_parser("init", help="Scaffold anchor hooks config/dirs in the current project")
    init_parser.add_argument("--dir", default=".", help="Target project directory (default: current dir)")

    connect_parser = sub.add_parser(
        "connect", help="Save the Tally API key and perform the initial handshake with the ingest server"
    )
    connect_parser.add_argument(
        "--api-key", default=None, help="API key issued by the Tally server (or set TALLY_API_KEY in .env already)"
    )
    connect_parser.add_argument(
        "--api-url", default=None, help="Override the ingest API base URL (defaults to the configured one)"
    )
    connect_parser.add_argument("--dir", default=".", help="Target project directory (default: current dir)")

    args = parser.parse_args()

    if args.command == "init":
        init(args.dir)
    elif args.command == "connect":
        connect(args.api_key, args.api_url, args.dir)


if __name__ == "__main__":
    main()
