"""Regression check for HANDOFF detection against a synthetic supervisor +
two subagent subgraphs. HANDOFF relies on LangGraph's internal
`langgraph_checkpoint_ns` metadata (not public API) -- run this after any
LangGraph version upgrade to confirm handoffs still fire and are attributed
to the correct sending/receiving agent before trusting HANDOFF in production.

Also doubles as the regression check for AnchorCallbackHandler's
self-contained session tracking (SESSION_START/END + INSTRUCTION_RECEIVED
derived from the root on_chain_start/on_chain_end pair) -- no
AnchorSession/track() wrapper involved, matching real integration usage.

Run directly: python -m anchor_hooks.tests.test_handoff
"""
from __future__ import annotations

import shutil
import tempfile
from typing import TypedDict

from langgraph.graph import END, START, StateGraph

from anchor_hooks.callback_handler import AnchorCallbackHandler
from anchor_hooks.config import AnchorConfig


class _State(TypedDict):
    x: str


def _build_supervisor_graph():
    def sub_a_step(state):
        return {"x": state["x"] + "-suba"}

    def sub_b_step(state):
        return {"x": state["x"] + "-subb"}

    def supervisor(state):
        return {"x": state["x"] + "-sup"}

    sub_a = StateGraph(_State)
    sub_a.add_node("sub_a_step", sub_a_step)
    sub_a.add_edge(START, "sub_a_step")
    sub_a.add_edge("sub_a_step", END)

    sub_b = StateGraph(_State)
    sub_b.add_node("sub_b_step", sub_b_step)
    sub_b.add_edge(START, "sub_b_step")
    sub_b.add_edge("sub_b_step", END)

    outer = StateGraph(_State)
    outer.add_node("supervisor", supervisor)
    outer.add_node("subagent_a", sub_a.compile())
    outer.add_node("subagent_b", sub_b.compile())
    outer.add_edge(START, "supervisor")
    outer.add_edge("supervisor", "subagent_a")
    outer.add_edge("subagent_a", "subagent_b")
    outer.add_edge("subagent_b", END)
    return outer.compile()


def run_check() -> bool:
    tmp_dir = tempfile.mkdtemp(prefix="anchor_handoff_test_")
    try:
        config = AnchorConfig(log_dir=tmp_dir)
        app = _build_supervisor_graph()

        # Real integration usage: one handler instance, added to the existing
        # callbacks list, nothing else changed at the call site.
        app.invoke({"x": "start"}, config={"callbacks": [AnchorCallbackHandler(config=config)]})

        records = []
        with open(config.log_jsonl_path) as f:
            for line in f:
                import json

                records.append(json.loads(line))

        record_types = [r["record_type"] for r in records]
        lifecycle_ok = (
            record_types[0] == "SESSION_START"
            and "INSTRUCTION_RECEIVED" in record_types
            and record_types[-1] == "SESSION_END"
        )

        handoffs = [r for r in records if r["record_type"] == "HANDOFF"]
        expected = [
            ("supervisor", "subagent_a"),
            ("subagent_a", "subagent_b"),
        ]
        actual = [(h["sending_agent"], h["receiving_subagent_type"]) for h in handoffs]

        ok = lifecycle_ok and actual == expected
        print(f"Record sequence: {record_types}")
        print(f"HANDOFF sequence: {actual}")
        print("PASS" if ok else f"FAIL -- expected lifecycle SESSION_START..SESSION_END and handoffs {expected}")
        return ok
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)


if __name__ == "__main__":
    import sys

    sys.exit(0 if run_check() else 1)
