"""Helpers shared by record builders."""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Optional


def now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def truncate(text: Optional[str], max_len: int = 500) -> Optional[str]:
    if text is None:
        return None
    if len(text) <= max_len:
        return text
    return text[:max_len] + f"...({len(text) - max_len} more chars truncated)"
