"""Initial handshake with the Tally ingest API.

Mirrors the JS installer's notifyClientConnected() (see the Claude Code hooks
installer's server.js): a best-effort POST telling the server a client has
just configured log shipping, sent once (from `anchor-hooks connect`) using
the same API key that will later be used to ship log records. A failure here
must never block or fail API key setup -- the forwarder daemon will still
ship logs on its own schedule regardless of whether the handshake succeeded.
"""
from __future__ import annotations

from urllib.parse import urlsplit, urlunsplit

import requests

HANDSHAKE_PATH = "/v1/tally/onboarding/client-connected"
REQUEST_TIMEOUT_SECONDS = 10
HANDSHAKE_SOURCE = "github-monitor-agent"


def _handshake_url(api_url: str) -> str:
    parts = urlsplit(api_url)
    return urlunsplit((parts.scheme, parts.netloc, HANDSHAKE_PATH, "", ""))


def notify_client_connected(api_key: str, api_url: str) -> bool:
    """POST a one-shot "client connected" notification. Returns True on a
    2xx response, False on any failure (network error, non-2xx, bad URL) --
    never raises.
    """
    try:
        response = requests.post(
            _handshake_url(api_url),
            json={"source": HANDSHAKE_SOURCE},
            headers={
                "x-api-key": api_key,
                "Content-Type": "application/json",
            },
            timeout=REQUEST_TIMEOUT_SECONDS,
        )
        response.raise_for_status()
        return True
    except requests.RequestException as exc:
        print(f"[anchor_hooks] handshake notification failed (non-fatal): {exc}")
        return False
