"""AnchorSession: explicit, manual alternative to AnchorCallbackHandler for
agents that have no LangChain Runnable to attach a callback handler to (so
there's no on_chain_start/on_chain_end to derive session boundaries from).
Emits SESSION_START/SESSION_END/INSTRUCTION_RECEIVED/ACTION_TAKEN/
RESULT_RECEIVED/HANDOFF via explicit method calls instead, and manages the
same per-session heartbeat daemon plus the singleton log forwarder daemon
(shared implementation in daemons.py).

For any agent built on LangGraph/LangChain, prefer AnchorCallbackHandler
instead -- it captures the same records automatically from callback events,
with zero changes needed beyond adding it to an existing `callbacks` list.
Use AnchorSession only when there's no such callback flow to hook into.
"""
from __future__ import annotations

import uuid
from contextlib import contextmanager
from typing import Optional

from . import daemons
from .config import AnchorConfig, load_config
from .schema import now_iso, truncate
from .sink import LogSink

INSTRUCTION_TRUNCATE_LEN = 500


class AnchorSession:
    def __init__(
        self,
        config_path: Optional[str] = None,
        agent_id: Optional[str] = None,
        agent_version: Optional[str] = None,
        principal_id: Optional[str] = None,
        config: Optional[AnchorConfig] = None,
    ):
        self.config = config or load_config(config_path)
        if agent_id:
            self.config.agent_id = agent_id
        if agent_version:
            self.config.agent_version = agent_version
        if principal_id:
            self.config.principal_id = principal_id

        self.sink = LogSink(self.config)
        self.session_id = f"sess_{uuid.uuid4()}"
        self._instruction_id: Optional[str] = None

    # -- record emitters ----------------------------------------------------
    def emit_session_start(self, source: str) -> None:
        self.sink.write({
            "schema_version": self.config.schema_version,
            "record_type": "SESSION_START",
            "session_id": self.session_id,
            "agent_id": self.config.agent_id,
            "agent_version": self.config.agent_version,
            "principal": {"type": "user", "id": self.config.principal_id},
            "source": source,
            "session_started_at": now_iso(),
        })

    def emit_instruction_received(self, text: str) -> str:
        self._instruction_id = f"instr_{uuid.uuid4().hex[:8]}"
        self.sink.write({
            "schema_version": self.config.schema_version,
            "record_type": "INSTRUCTION_RECEIVED",
            "session_id": self.session_id,
            "instruction_id": self._instruction_id,
            "sender": {"id": self.config.principal_id},
            "declared_intent": {"summary": truncate(text, INSTRUCTION_TRUNCATE_LEN)},
            "instruction_received_at": now_iso(),
        })
        return self._instruction_id

    def emit_action_taken(self, action_id: str, tool_name: str, params: str) -> None:
        self.sink.write({
            "schema_version": self.config.schema_version,
            "record_type": "ACTION_TAKEN",
            "session_id": self.session_id,
            "action_id": action_id,
            "instruction_id": self._instruction_id,
            "action_type": "tool_call",
            "tool": {"name": tool_name, "params": params},
            "pre_state_hash": "0" * 64,
            "post_state_hash": None,
            "action_timestamp": now_iso(),
            "deviance_flag": {"deviated": False, "delta_category": None},
        })

    def emit_result_received(self, action_id: str, summary: str, exception: bool) -> None:
        self.sink.write({
            "schema_version": self.config.schema_version,
            "record_type": "RESULT_RECEIVED",
            "session_id": self.session_id,
            "action_id": action_id,
            "result_interpretation": {"summary": summary},
            "result_received_at": now_iso(),
            "exception": {"occurred": exception},
        })

    def emit_handoff(self, sending_agent: str, receiving_subagent: str) -> None:
        self.sink.write({
            "schema_version": self.config.schema_version,
            "record_type": "HANDOFF",
            "session_id": self.session_id,
            "handoff_id": f"handoff_{uuid.uuid4().hex[:8]}",
            "sending_agent": sending_agent,
            "receiving_subagent_type": receiving_subagent,
            "acknowledgement_status": "pending",
            "handoff_at": now_iso(),
        })

    def emit_session_end(self, outcome: str) -> None:
        self.sink.write({
            "schema_version": self.config.schema_version,
            "record_type": "SESSION_END",
            "session_id": self.session_id,
            "outcome": outcome,
            "session_ended_at": now_iso(),
        })

    # -- public entrypoint ------------------------------------------------
    @contextmanager
    def track(self, source: str = "startup", outcome_on_success: str = "completed"):
        self.emit_session_start(source)
        daemons.start_heartbeat_daemon(self.config, self.session_id)
        daemons.start_forwarder_daemon(self.config)
        try:
            yield self
        except BaseException:
            self.emit_session_end("error")
            daemons.stop_heartbeat_daemon(self.config, self.session_id)
            raise
        else:
            self.emit_session_end(outcome_on_success)
            daemons.stop_heartbeat_daemon(self.config, self.session_id)
